import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Collections;
import java.util.List;


public class Perceptron extends SupervisedLearner {

    private double[] weights;
    private Random rand;

    public Perceptron(Random rand) {
        this.rand = rand;
    }
    @Override
    public void train(DataMatrix featuresOnlyDataMatrix, DataMatrix labelsOnlyDataMatrix) throws Exception {
        int numFeatures = featuresOnlyDataMatrix.getColCount();
        int numClasses = labelsOnlyDataMatrix.getValueCountForAttributeAtColumn(0);
        weights = new double[numFeatures + 1]; // +1 for bias

        // Initialize weights with random values
        for (int i = 0; i < weights.length; i++) {
            weights[i] = rand.nextDouble() * 2 - 1; // Random value between -1 and 1
        }

        double learningRate = 0.1;
        int epochsWithoutImprovement = 0;
        double bestAccuracy = 0.0;
        List<Integer> instanceIndices = new ArrayList();
        for (int i = 0; i < featuresOnlyDataMatrix.getRowCount(); i++) {
            instanceIndices.add(i);
        }

        for (int epoch = 0; ; epoch++) { // Removed the fixed maximum number of epochs
            int correctCount = 0;
         // Shuffle the data order
            Collections.shuffle(instanceIndices, rand);

            for (int i : instanceIndices) {
                double[] features = featuresOnlyDataMatrix.getRow(i);
                int label = (int) labelsOnlyDataMatrix.getValueAt(i, 0);

                // Add a bias (input = 1) to the features
                double[] inputs = new double[numFeatures + 1];
                System.arraycopy(features, 0, inputs, 1, numFeatures);
                inputs[0] = 1.0;

                double predicted = predict(inputs);
                int predictedLabel = (predicted > 0) ? 1 : 0;

                if (predictedLabel == label) {
                    correctCount++;
                } else {
                    // Update weights if prediction is incorrect
                    for (int j = 0; j < weights.length; j++) {
                        weights[j] += learningRate * (label - predictedLabel) * inputs[j];
                    }
                }
            }

            DataMatrix confusion = new DataMatrix();
            double accuracy = measurePredictiveAccuracy(featuresOnlyDataMatrix, labelsOnlyDataMatrix, confusion);

            if (accuracy > bestAccuracy) {
                bestAccuracy = accuracy;
                epochsWithoutImprovement = 0;
            } else {
                epochsWithoutImprovement++;
            }

            System.out.println("Epoch " + epoch + ", Learning Rate: " + learningRate + ", Accuracy: " + accuracy);
            System.out.println("Weights: " + Arrays.toString(weights));

            if (epochsWithoutImprovement >= 5) {
                break;
            }
        }
    }
    @Override
    public void predictInstanceLabelsFromFeatures(double[] featureVector, double[] arrayInWhichToPutLabels)
            throws Exception {
        // Add a bias (input = 1) to the features
        double[] inputs = new double[featureVector.length + 1];
        System.arraycopy(featureVector, 0, inputs, 1, featureVector.length);
        inputs[0] = 1.0;

        double predicted = predict(inputs);

        // Assign predicted label based on sign of predicted value
        arrayInWhichToPutLabels[0] = (predicted > 0) ? 1 : 0;
    }

    private double predict(double[] inputs) {
        double sum = 0.0;
        for (int i = 0; i < inputs.length; i++) {
            sum += weights[i] * inputs[i];
        }
        return sum;
    }
}
