import java.util.ArrayList;
import java.util.Random;
import java.util.*;

public class InstanceBasedLearner extends SupervisedLearner {

    public DataMatrix savedFeaturesMatrix;
    public DataMatrix savedLabelsMatrix;
    public int kValue = 3; // start at 1, 3, 5, 7, 9, 11, 13, etc.
    public boolean useRegression = true;
    public boolean useWeightedDistance = true;

    public void train(DataMatrix featuresOnlyDataMatrix, DataMatrix labelsOnlyDataMatrix) throws Exception {
        savedFeaturesMatrix = featuresOnlyDataMatrix;
        savedLabelsMatrix = labelsOnlyDataMatrix;
    }

    public void predictInstanceLabelsFromFeatures(double[] featureVector, double[] arrayInWhichToPutLabels) throws Exception {
        ArrayList<KNNPoint> distanceTable = new ArrayList<KNNPoint>();
        distanceTable = initializeDistanceTableWithZeroValues(distanceTable);
        distanceTable = makeDistanceLookupTable(distanceTable, featureVector);
        distanceTable = sortTheDistanceLookupTable(distanceTable);
        arrayInWhichToPutLabels[0] = extractLabelWithMostVotes(distanceTable);
    }

    private ArrayList<KNNPoint> makeDistanceLookupTable(ArrayList<KNNPoint> distanceTable, double[] featuresForPrediction) {
        int counterOfRowWeAreInsertingAt = 0;
        for (int trainingInstance = 0; trainingInstance < savedFeaturesMatrix.getRowCount(); trainingInstance++) {
            double distBetweenTwoPoints = 0;
            double inverseDistSquared = 0;
            for (int col = 0; col < savedFeaturesMatrix.getColCount(); col++) {

                if (savedFeaturesMatrix.getValueCountForAttributeAtColumn(col) == 0) {  // this means that this is a continuous attribute
                    double differenceForOneVariable = (savedFeaturesMatrix.getValueAt(trainingInstance, col) - featuresForPrediction[col]);
                    distBetweenTwoPoints += (differenceForOneVariable * differenceForOneVariable);
                } else {        // this means that this is a nominal attribute
                    if (savedFeaturesMatrix.getValueAt(trainingInstance, col) != featuresForPrediction[col]) {
                        distBetweenTwoPoints += 1;
                    }
                }
            }
            inverseDistSquared = (1 / (distBetweenTwoPoints + 0.0000001));
            KNNPoint pointToInsert = distanceTable.get(counterOfRowWeAreInsertingAt);
            pointToInsert.distanceFromPointWereTryingToPredict = distBetweenTwoPoints;
            pointToInsert.trainingInstanceIndex = trainingInstance;
            pointToInsert.inverseDistanceSquared = inverseDistSquared;
            distanceTable.set(counterOfRowWeAreInsertingAt, pointToInsert);

            counterOfRowWeAreInsertingAt++;
        }
        return distanceTable;
    }

    private ArrayList<KNNPoint> sortTheDistanceLookupTable(ArrayList<KNNPoint> distanceTable) {
        Collections.sort(distanceTable, new Comparator<KNNPoint>() {
            public int compare(KNNPoint element1, KNNPoint element2) {
                double knnPoint1Dist = (double) element1.distanceFromPointWereTryingToPredict;
                double knnPoint2Dist = (double) element2.distanceFromPointWereTryingToPredict;
                if (knnPoint1Dist < knnPoint2Dist) return -1;
                if (knnPoint1Dist > knnPoint2Dist) return 1;
                return 0;
            }
        });
        return distanceTable;
    }

    private double extractLabelWithMostVotes(ArrayList<KNNPoint> distanceTable) {
        if (useRegression) {
            return computeRegression(distanceTable);
        }
        double labelToReturn = -1; // some arbitrary value
        double[] labelBuckets = new double[savedLabelsMatrix.getValueCountForAttributeAtColumn(0)];
        for (int pointNumber = 0; pointNumber < kValue; pointNumber++) {
            KNNPoint oneOfKClosestPoints = distanceTable.get(pointNumber);
            int originalRowIndexInLabelsMatrix = oneOfKClosestPoints.trainingInstanceIndex;
            double labelAtThisPoint = savedLabelsMatrix.getValueAt(originalRowIndexInLabelsMatrix, 0);
            if (useWeightedDistance) {
                labelBuckets[(int) labelAtThisPoint] += (oneOfKClosestPoints.inverseDistanceSquared);
            } else {
                labelBuckets[(int) labelAtThisPoint]++;
            }
        }
        double storedMax = Double.MIN_VALUE;
        for (int i = 0; i < savedLabelsMatrix.getValueCountForAttributeAtColumn(0); i++) {
            if (labelBuckets[i] > storedMax) {
                storedMax = labelBuckets[i];
                labelToReturn = i;
            }
        }
        return labelToReturn;
    }

    public double computeRegression(ArrayList<KNNPoint> distanceTable) {
        if (useWeightedDistance) { // WEIGHTED
            double weightedAverage = 0;
            double sumOfTheDistanceWeights = 0;
            for (int k = 0; k < kValue; k++) {
                double distBetweenTwoPoints = distanceTable.get(k).inverseDistanceSquared;
                sumOfTheDistanceWeights += distBetweenTwoPoints;
                weightedAverage += (savedLabelsMatrix.getValueAt((distanceTable.get(k).trainingInstanceIndex), 0) * distBetweenTwoPoints);
            }
            weightedAverage = (weightedAverage / sumOfTheDistanceWeights);
            return weightedAverage;
        }
        // UNWEIGHTED
        double weightedAverage = 0;
        for (int k = 0; k < kValue; k++) {
            weightedAverage += (savedLabelsMatrix.getValueAt((distanceTable.get(k).trainingInstanceIndex), 0));
        }
        weightedAverage = (weightedAverage / kValue);
        return weightedAverage;
    }

    public ArrayList<KNNPoint> initializeDistanceTableWithZeroValues(ArrayList<KNNPoint> distanceTable) {
        for (int row = 0; row < savedFeaturesMatrix.getRowCount(); row++) {
            KNNPoint initializedPoint = new KNNPoint();
            distanceTable.add(row, initializedPoint);
        }
        return distanceTable;
    }
}
