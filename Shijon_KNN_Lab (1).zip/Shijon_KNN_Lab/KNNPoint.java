import java.util.ArrayList;

public class KNNPoint {
	double distanceFromPointWereTryingToPredict;
	int trainingInstanceIndex;
	double inverseDistanceSquared;
}