import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;
import java.lang.*;
import java.math.RoundingMode;
import java.util.*;

public class KMeansClusterer extends SupervisedLearner {
	
	public int kValue = 7;
	public double sseFromPreviousIteration;
	public boolean reachedConvergence;
	
	public KMeansClusterer(DataMatrix data){
		
		sseFromPreviousIteration = Double.MAX_VALUE; 
		reachedConvergence = false;
		
		int iterationCounter = 1;
		
		int[] assignedCentroids = new int[ data.getRowCount() ];
		// For our centroid, choose the first k points in data set
		ArrayList<double[]> centroids = new ArrayList<double[]>();
		centroids = initializeTheCentroidsArrayList( centroids, data );
		while( reachedConvergence == false ) { // while we haven't converged yet
			
			System.out.println( "\n--------------------------");
			System.out.println("Iteration " + iterationCounter);
			System.out.println("---------------------------");
			System.out.println("Computing Centroids:" );
			// We assign all training instances to closest centroid
			printOutCentroidLocations( centroids , data);
			assignedCentroids = assignAllTrainingInstancesToClosestCentroid( centroids, data, assignedCentroids);
			int[] histogram = printOutHowManyInstancesPerCluster( assignedCentroids );
			printOutAssignments( assignedCentroids);
			centroids = calculateNewCentroidPositions( centroids, data, assignedCentroids );
			iterationCounter++;
		}
		System.out.println("\nSSE has converged\n");
		int[] histogram = printOutHowManyInstancesPerCluster( assignedCentroids );
		//calculateSilhouetteScore( centroids, data , assignedCentroids, histogram);

	}
	
	/*
	 * We initialize ArrayList with first k points in data set, 
	 * or we initialize it with k random data points
	 */
	
	//public ArrayList<double[]> initializeTheCentroidsArrayList(ArrayList<double[]> centroids, DataMatrix data) {
	  //  for (int centroidIndex = 0; centroidIndex < kValue; centroidIndex++) {
	    //    double[] centroidFeatureVector = new double[data.getColCount()];
	      //  for (int colOfFeatureVector = 0; colOfFeatureVector < data.getColCount(); colOfFeatureVector++) {
	        //    centroidFeatureVector[colOfFeatureVector] = data.getValueAt(centroidIndex, colOfFeatureVector);
	        //}
	        //centroids.add(centroidFeatureVector);
	    //}
	    //return centroids;
	//}
	
	public ArrayList<double[]> initializeTheCentroidsArrayList( ArrayList<double[]> centroids, DataMatrix data ) {
		HashSet<Integer> myRandomDataPointsSet= new HashSet<Integer>();
		Random rand = new Random();
		for( int i = 0; i < kValue; i++ ) {
			int nextRandomDataPoint = rand.nextInt(data.getRowCount());
			while( myRandomDataPointsSet.contains(nextRandomDataPoint) ) {
				nextRandomDataPoint = rand.nextInt(data.getRowCount());
			}
			myRandomDataPointsSet.add( nextRandomDataPoint);
		}

		Iterator iterator = myRandomDataPointsSet.iterator();  // create an iterator
		      
		// check values
		while (iterator.hasNext() ) {
			int myInstanceNumber = (Integer)iterator.next();
			double[] randomDataPointsFeatureVector = new double[ data.getColCount() ];  
			for( int colOfFeatureVector = 0; colOfFeatureVector < data.getColCount() ; colOfFeatureVector++ ) {
				randomDataPointsFeatureVector[ colOfFeatureVector ] = data.getValueAt( myInstanceNumber , colOfFeatureVector);
			}
		centroids.add( randomDataPointsFeatureVector );
		}
		   

		return centroids;
	}

	public int[] assignAllTrainingInstancesToClosestCentroid( ArrayList<double[]> centroids, DataMatrix data, int[] assignedCentroids) {
		for( int instanceWeAreAssigning = 0; instanceWeAreAssigning < data.getRowCount() ; instanceWeAreAssigning++ ) {
			double minDistanceBetweenTwoPoints = Double.MAX_VALUE;
			int closestCentroid = -1;
			for( int centroidIndex = 0; centroidIndex < kValue; centroidIndex++ ) {
				double distBetweenPointAndCentroid = 0;
				
				for( int col = 0; col < data.getColCount(); col++ ) {
					if( data.getValueCountForAttributeAtColumn(col) == 0) {  // this means that this is a continuous attribute
						if( data.getValueAt(instanceWeAreAssigning, col) == Double.MAX_VALUE ) { 		// check to see if it is missing value
							
							distBetweenPointAndCentroid += 1;
						} else {
							if( centroids.get( centroidIndex)[col] == Double.MAX_VALUE) { // the centroid had a missing value
								distBetweenPointAndCentroid += 1;
							} else {
								double differenceForOneVariable = ( data.getValueAt( instanceWeAreAssigning,col) - centroids.get(centroidIndex)[col] ); 
								distBetweenPointAndCentroid += Math.abs(differenceForOneVariable );	
							}	
						}
					} else {  		// this means that this is a nominal attribute
						if( data.getValueAt(instanceWeAreAssigning, col) == Double.MAX_VALUE ) { 		// check to see if it is missing value
							
							distBetweenPointAndCentroid += 1;
						} else {
							if( data.getValueAt(instanceWeAreAssigning, col) == centroids.get(centroidIndex )[col] ) {
								distBetweenPointAndCentroid += 0;
							} else {
								distBetweenPointAndCentroid += 1;
							}
						}
					}
				}
				if( distBetweenPointAndCentroid < minDistanceBetweenTwoPoints ){
					minDistanceBetweenTwoPoints = distBetweenPointAndCentroid;
					closestCentroid = centroidIndex;
				}
			}
			assignedCentroids[instanceWeAreAssigning] = closestCentroid;
		}
		
		double sseOnAllCentroids = calculateSSEOnAllCentroids( centroids, data , assignedCentroids );
		sseFromPreviousIteration = sseOnAllCentroids; // update global variable
	
		return assignedCentroids;
	}

	
	public double calculateSSEOnAllCentroids ( ArrayList<double[]> centroids, DataMatrix data , int[] assignedCentroids ) {
		double sseForAllCentroids = 0;
		for( int centroidIndex = 0; centroidIndex < kValue; centroidIndex++ ) { // for each centroid
			double sseForThisCentroid = 0;
			for( int col = 0; col < data.getColCount(); col++ ) { //for each column
				for( int trainingInstance = 0; trainingInstance < data.getRowCount(); trainingInstance++ ) { // for every data point in the centroid
					if( assignedCentroids[trainingInstance] == centroidIndex) {
						if( data.getValueCountForAttributeAtColumn(col) == 0) {  // this means that this is a continuous attribute
							// adding them all up, and take average
							if( (data.getValueAt(trainingInstance , col) == Double.MAX_VALUE) || (centroids.get(centroidIndex)[col] == Double.MAX_VALUE) ) { // we ignore missing values
								sseForThisCentroid += 1;
							} else {
								double diffBetweenThePoints = ( data.getValueAt( trainingInstance ,col) - centroids.get(centroidIndex)[ col ] );
								sseForThisCentroid += (diffBetweenThePoints * diffBetweenThePoints );
							}
						} else {  		// this means that this is a nominal attribute
							if( (data.getValueAt(trainingInstance , col) == Double.MAX_VALUE) || (centroids.get(centroidIndex)[ col ] == Double.MAX_VALUE) ) { // we ignore missing values
								sseForThisCentroid += 1;
							} else {
								if( data.getValueAt(trainingInstance , col) != centroids.get(centroidIndex )[col] ) {
									sseForThisCentroid += 1;
								}
							}
						}	
					}	
				}
			}
			System.out.println( "SSE for centroid # " + centroidIndex + " is " + sseForThisCentroid );
			sseForAllCentroids += sseForThisCentroid;
		}
		System.out.println( "Total SSE= " + sseForAllCentroids);
		if( ( Math.abs(sseFromPreviousIteration - sseForAllCentroids) < 0.01) ) {
			reachedConvergence = true;
		}
		return sseForAllCentroids;
	}
	

	public ArrayList<double[]> calculateNewCentroidPositions( ArrayList<double[]> centroids, DataMatrix data, int[] assignedCentroids ) {
		// Finding the average location of all of the data points assigned to that cluster
		for( int centroidIndex = 0; centroidIndex < kValue; centroidIndex++ ) {
			double[] newFeatureVectorForCentroid = new double[ data.getColCount() ];
			for( int col = 0; col < data.getColCount(); col++ ) { 
				if( data.getValueCountForAttributeAtColumn(col) == 0) { // CONTINUOUS
					boolean weGotHere = false;
					int numDataPointsAssignedToThisCluster = 0;
					double averageForThisColumn = 0;
					for( int trainingInstance = 0; trainingInstance < data.getRowCount(); trainingInstance++ ) {
						if( assignedCentroids[trainingInstance] == centroidIndex) {
							weGotHere = true;
							if( data.getValueAt(trainingInstance, col) != Double.MAX_VALUE ) {
								numDataPointsAssignedToThisCluster++;
								averageForThisColumn += data.getValueAt(trainingInstance, col);
							}
						}
					}
					if( (weGotHere == true) && (numDataPointsAssignedToThisCluster == 0) ) {  // ADD IN SPECIAL CASE IF THEY ARE ALL MISSING INSIDE OF THE COLUMN
						newFeatureVectorForCentroid[col] = Double.MAX_VALUE;// they were all zero
					} else {
						averageForThisColumn = (averageForThisColumn / numDataPointsAssignedToThisCluster);
						newFeatureVectorForCentroid[col] = averageForThisColumn;
					}
				} else { // NOMINAL
					boolean weGotHere = false;
					int[] histogram = new int[ data.getColCount() ]; // find most common, use histogram
					for( int trainingInstance = 0; trainingInstance < data.getRowCount(); trainingInstance++ ) {
						if( assignedCentroids[trainingInstance] == centroidIndex) {
							weGotHere = true;
							if( data.getValueAt(trainingInstance, col) != Double.MAX_VALUE ) {
								histogram[ (int)data.getValueAt(trainingInstance, col) ]++;
							}
						}
					}

					int highestFrequency = Integer.MIN_VALUE;
					int mostFrequentValue = -1;
					for( int histogramIndex = 0; histogramIndex < histogram.length; histogramIndex++ ) {
						if( histogram[histogramIndex] > highestFrequency) {
							highestFrequency = histogram[histogramIndex];
							mostFrequentValue = histogramIndex;
						} else if( histogram[histogramIndex] == highestFrequency ) {
							if( mostFrequentValue > histogramIndex) { 
								mostFrequentValue = histogramIndex; // break ties by whichever one comes first in the metadata list
							}
						}	
					}
					if( (weGotHere == true) && (highestFrequency == 0) ) {  
						newFeatureVectorForCentroid[col] = Double.MAX_VALUE;
					} else {
						newFeatureVectorForCentroid[col] = mostFrequentValue;
					}
				}
			}
			centroids.set( centroidIndex, newFeatureVectorForCentroid ); // make this the new centroid for that cluster	
		}
		return centroids;
	}
	

	public void printOutCentroidLocations( ArrayList<double[]>centroids, DataMatrix data ) {
		DecimalFormat df = new DecimalFormat("#######.###");
		df.setRoundingMode(RoundingMode.CEILING);
		for( int i = 0; i < centroids.size(); i++ ) {
			System.out.print( "Centroid " + i +"= " );
			double[] array = centroids.get(i);
			for( int j = 0; j < array.length; j++ ) {
				//
				double value = array[j];
				if( value == Double.MAX_VALUE) {
					System.out.print("?, ");
				} else if( data.getValueCountForAttributeAtColumn(j) == 0 ){ // continuous
					
					System.out.printf( "%.3f" + ", ", array[j]);
					
				} else {
					System.out.printf( data.getAttributeValueName(j, (int)array[j]) + ", ");
				}
			}
			System.out.print("\n");
		}
	}
	
	
	public void printOutAssignments( int[] assignedCentroids) {
		System.out.println( "Making Assignments");
		for( int trainingInstance = 0; trainingInstance < assignedCentroids.length; trainingInstance++ ) {
			if( (trainingInstance % 10) == 0 ) {
				System.out.print("\n");
			}
			System.out.print( trainingInstance + "=" + assignedCentroids[trainingInstance] + " ");
		}
	}


	public int[] printOutHowManyInstancesPerCluster( int[] assignedCentroids ) {
		int[] histogram = new int[ kValue ];
		for( int trainingInstance = 0; trainingInstance < assignedCentroids.length; trainingInstance++ ) {
			histogram[ assignedCentroids[trainingInstance] ]++;
		}
		for( int i = 0; i < histogram.length; i++ ) {
			System.out.println( "Centroid " + i + " has " + histogram[i] + " in it.");
		}
		return histogram;
	}

	
	
	public void calculateSilhouetteScore( ArrayList<double[]>centroids, DataMatrix data , int[] assignedCentroids,
			int[] histogram ) {
		double globalSilhouetteScore = 0;
		for( int centroidIndex = 0; centroidIndex < kValue; centroidIndex++ ) {
			double averageDistanceToCentroidFromPointsWithin = computeAverageDistanceToCentroidFromPointsWithin( centroids, data, assignedCentroids, histogram, centroidIndex );
			System.out.println( "Centroid #" + centroidIndex + " has a-value: " + averageDistanceToCentroidFromPointsWithin);
			
			double avgDistFromThisCentroidToPointsInNextNearestCluster = computeAvgDistFromThisCentroidToPointsInNextNearestCluster ( 
					centroids, data, assignedCentroids, histogram, centroidIndex );
			
			double silhouetteScore = ( (avgDistFromThisCentroidToPointsInNextNearestCluster - averageDistanceToCentroidFromPointsWithin ) / 
					Math.max(averageDistanceToCentroidFromPointsWithin, avgDistFromThisCentroidToPointsInNextNearestCluster) );
			System.out.println( "Centroid #" + centroidIndex + " has silhouette score: " + silhouetteScore);
			globalSilhouetteScore += silhouetteScore;
		}
		globalSilhouetteScore /= kValue;
		System.out.println( "GLOBAL SILHOUETTE SCORE IS: " + globalSilhouetteScore );
	}
	
	public double computeAvgDistFromThisCentroidToPointsInNextNearestCluster ( 
			ArrayList<double[]> centroids, DataMatrix data, int[] assignedCentroids, int[] histogram, int centroidIndex ) {
		double avgDistFromThisCentroidToPointsInNextNearestCluster = 0;
		
		double distToClosestCentroid = Double.MAX_VALUE;
		int closestCentroid = -1;
		for( int otherCentroidIndex = 0; otherCentroidIndex < kValue; otherCentroidIndex++ ) {
			if( otherCentroidIndex == centroidIndex) continue;
			double distToOtherCentroid = computeDistanceBetweenPoints( centroids.get(centroidIndex), centroids.get(otherCentroidIndex), data);
			if( distToOtherCentroid < distToClosestCentroid) {
				distToClosestCentroid = distToOtherCentroid;
				closestCentroid = otherCentroidIndex;
			}
		}
		
		for( int trainingInstance = 0; trainingInstance < assignedCentroids.length; trainingInstance++ ) {
			if( assignedCentroids[trainingInstance] == closestCentroid) {
				double[] thatInstancesFeatureVector = new double[ data.getRowCount() ];
				for( int col = 0; col < data.getColCount(); col++ ) {
					thatInstancesFeatureVector[col] = data.getValueAt( trainingInstance, col);
				}
				double distFromMyCentroidToThatCentroidsPoint = computeDistanceBetweenPoints(  centroids.get( centroidIndex), thatInstancesFeatureVector, data);
				
				avgDistFromThisCentroidToPointsInNextNearestCluster += distFromMyCentroidToThatCentroidsPoint;
			}
		}
		avgDistFromThisCentroidToPointsInNextNearestCluster /= (histogram[closestCentroid]);
		return avgDistFromThisCentroidToPointsInNextNearestCluster;
	}
	
	
	/*
	 * 
	 */
	public double computeDistanceBetweenPoints( double[] centroidOne, double[] centroidTwo, DataMatrix data ) {
		double distBetweenTwoCentroids = 0;
		
		for( int col = 0; col < data.getColCount(); col++ ) {
			if( data.getValueCountForAttributeAtColumn(col) == 0) {  // this means that this is a continuous attribute
				if( centroidOne[col] == Double.MAX_VALUE ) { 		// check to see if it is missing value
					
					distBetweenTwoCentroids += 1;
				} else {
					if( centroidTwo[col] == Double.MAX_VALUE) { // the centroid had a missing value
						distBetweenTwoCentroids += 1;
					} else {
						double differenceForOneVariable = ( centroidOne[col] - centroidTwo[col] ); 
						distBetweenTwoCentroids += Math.abs(differenceForOneVariable );	
					}	
				}
			} else {  		// this means that this is a nominal attribute
				if( centroidOne[col] == Double.MAX_VALUE ) { 		// check to see if it is missing value
					
					distBetweenTwoCentroids += 1;
				} else {
					if( centroidOne[col] == centroidTwo[col] ) {
						distBetweenTwoCentroids += 0;
					} else {
						distBetweenTwoCentroids += 1;
					}
				}
			}
		}
		return Math.sqrt(distBetweenTwoCentroids);
	}
	

	public double computeAverageDistanceToCentroidFromPointsWithin( ArrayList<double[]>centroids, DataMatrix data , int[] assignedCentroids,
			int[] histogram, int centroidIndex ) {
		double averageDistanceToCentroidFromPointsWithin = 0;
		for( int trainingInstance = 0; trainingInstance < data.getRowCount() ; trainingInstance++ ) {
			if( assignedCentroids[trainingInstance] == centroidIndex ) {
				double distBetweenPointAndCentroid = 0;
				
				for( int col = 0; col < data.getColCount(); col++ ) {
					if( data.getValueCountForAttributeAtColumn(col) == 0) {  // this means that this is a continuous attribute
						if( data.getValueAt(trainingInstance, col) == Double.MAX_VALUE ) { 		// check to see if it is missing value
							
							distBetweenPointAndCentroid += 1;
						} else {
							if( centroids.get( centroidIndex)[col] == Double.MAX_VALUE) { // the centroid had a missing value
								distBetweenPointAndCentroid += 1;
							} else {
								double differenceForOneVariable = ( data.getValueAt( trainingInstance,col) - centroids.get(centroidIndex)[col] ); 
								distBetweenPointAndCentroid += Math.abs(differenceForOneVariable );	
							}	
						}
					} else {  		// this means that this is a nominal attribute
						if( data.getValueAt(trainingInstance, col) == Double.MAX_VALUE ) { 		// check to see if it is missing value
							
							distBetweenPointAndCentroid += 1;
						} else {
							if( data.getValueAt(trainingInstance, col) == centroids.get(centroidIndex )[col] ) {
								distBetweenPointAndCentroid += 0;
							} else {
								distBetweenPointAndCentroid += 1;
							}
						}
					}
				}
				averageDistanceToCentroidFromPointsWithin += distBetweenPointAndCentroid;
			}
		}
		
		averageDistanceToCentroidFromPointsWithin /= ( histogram[centroidIndex] );
		return averageDistanceToCentroidFromPointsWithin;
	}

	@Override
	public void train(DataMatrix featuresOnlyDataMatrix, DataMatrix labelsOnlyDataMatrix) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void predictInstanceLabelsFromFeatures(double[] featureVector, double[] arrayInWhichToPutLabels)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

}