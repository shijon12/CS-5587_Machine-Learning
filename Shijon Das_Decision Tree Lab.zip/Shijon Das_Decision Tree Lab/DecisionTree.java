

import java.util.ArrayList;
import java.util.Random;
import java.lang.*;
import java.util.*;

public class DecisionTree extends SupervisedLearner {
	
	private int globalNodeCounter;
	
	DataMatrix binnedFeatureMatrix;
	DataMatrix globalOriginalFeatures;
	DataMatrix globalOriginalLabels;
	private Stack classStackOfNodesFromLeavesToRoot;
	private int[] classHistogramOfMostCommonValuesPerFeature;
	// root node has no parent
	private Node trainedDecisionTree;
	private double validationSetPercentageOfData = 0.80;
	
	public void train(DataMatrix featuresOnlyDataMatrix, DataMatrix labelsOnlyDataMatrix) throws Exception {
		
		globalOriginalFeatures = featuresOnlyDataMatrix;
		globalOriginalLabels = labelsOnlyDataMatrix;
	
//----------SPLIT OFF A VALIDATION SET-------------------------------------------------------
		// IMMEDIATELY SAVE SOME OF THIS, NEVER WILL TRAIN ON THESE, STICK THESE INTO A VALIDATION SET
		// ONCE accuracy starts to decrease ON THE VALIDATION SET, WE will stop the pruning
		int numRowsToGetIntoTrainingSet = (int)(featuresOnlyDataMatrix.getRowCount() * validationSetPercentageOfData );
		DataMatrix featuresForTrainingTrimmed = new DataMatrix();
		featuresForTrainingTrimmed.setSize( numRowsToGetIntoTrainingSet , featuresOnlyDataMatrix.getColCount() );
		DataMatrix featuresValidationSet = new DataMatrix();
		featuresValidationSet.setSize( featuresOnlyDataMatrix.getRowCount() - numRowsToGetIntoTrainingSet, featuresOnlyDataMatrix.getColCount() );
		DataMatrix labelsForTrainingTrimmed = new DataMatrix();
		labelsForTrainingTrimmed.setSize( numRowsToGetIntoTrainingSet , labelsOnlyDataMatrix.getColCount() );
		DataMatrix labelsValidationSet = new DataMatrix();
		labelsValidationSet.setSize( featuresOnlyDataMatrix.getRowCount() - numRowsToGetIntoTrainingSet, labelsOnlyDataMatrix.getColCount() );
		// LOOP THROUGH AND PUT MOST OF FEATURES INTO featuresForTrainingTrimmed
		for( int row = 0; row < featuresOnlyDataMatrix.getRowCount() ; row++ ) {
			for( int col = 0; col < featuresOnlyDataMatrix.getColCount() ; col++ ) {
				if( row < numRowsToGetIntoTrainingSet ) {
					featuresForTrainingTrimmed.setValue( row, col, featuresOnlyDataMatrix.getValueAt(row, col) );
				} else {
					featuresValidationSet.setValue( row - numRowsToGetIntoTrainingSet , col  , featuresOnlyDataMatrix.getValueAt(row, col) );
				}
			}
		}
		// LOOP THROUGH AND PUT MOST OF labels INTO labelsForTrainingTrimmed
		for( int row = 0; row < labelsOnlyDataMatrix.getRowCount() ; row++ ) {
			for( int col = 0; col < labelsOnlyDataMatrix.getColCount() ; col++ ) {
				if( row < numRowsToGetIntoTrainingSet ) {
					labelsForTrainingTrimmed.setValue( row, col, labelsOnlyDataMatrix.getValueAt(row, col) );
				} else {
					labelsValidationSet.setValue( row - numRowsToGetIntoTrainingSet , col  , labelsOnlyDataMatrix.getValueAt(row, col) );
				}
			}
		}
		featuresOnlyDataMatrix = featuresForTrainingTrimmed;
		labelsOnlyDataMatrix = labelsForTrainingTrimmed;
	
//-------------PERFORM THE TRAINING------------------------------------------------------------------------
		
		
		
		classHistogramOfMostCommonValuesPerFeature = new int[ featuresOnlyDataMatrix.getColCount() ];
		for( int col = 0; col < featuresOnlyDataMatrix.getColCount() ; col++ ) {
			classHistogramOfMostCommonValuesPerFeature[col] = (int)featuresOnlyDataMatrix.getMostCommonValueForColumn(col); // STASH MOST COMMON VALUES
		}
		
		Node rootNode = new Node();
		int[] skipColsArray = new int[ featuresOnlyDataMatrix.getColCount() ];
		int[] skipRowsArray = new int[ featuresOnlyDataMatrix.getRowCount() ];
		rootNode = makeTreeRec( rootNode, featuresOnlyDataMatrix, labelsOnlyDataMatrix , skipColsArray, skipRowsArray);
		trainedDecisionTree = rootNode;
		double currentTrainingAccuracy = this.measurePredictiveAccuracy( featuresOnlyDataMatrix, labelsOnlyDataMatrix, null);
		System.out.println( "training set accuracy" +  currentTrainingAccuracy);
		//This is where the pruning takes place
		
		
		System.out.println( "This many nodes before we prune" );
		countNodesInPrunedTree( trainedDecisionTree);
		createStackOfNodesFromBottomUp(); // pruning algorithm
		pruneTheDecisionTreeAndMeasureResults( featuresValidationSet, labelsValidationSet); 
		System.out.println("Tree is pruned");
		countNodesInPrunedTree( trainedDecisionTree);
		
		

	}
	
	/*
	 * propagate the data through the tree and predict on it
	 */
	public void predictInstanceLabelsFromFeatures(double[] featureVector, double[] arrayInWhichToPutLabels) throws Exception {
		globalNodeCounter = 1;
		Node childToExplore = new Node();
		if( trainedDecisionTree.children != null ) {
			double featureValueFromMatrix = featureVector[ trainedDecisionTree.attributesNumberThatWeSplitOn ];
			if( featureValueFromMatrix == Double.MAX_VALUE) {
				featureValueFromMatrix = classHistogramOfMostCommonValuesPerFeature[ trainedDecisionTree.attributesNumberThatWeSplitOn ];
			}
			if( (int)featureValueFromMatrix < trainedDecisionTree.children.size() ) {
				childToExplore = trainedDecisionTree.children.get((int)featureValueFromMatrix);
			} else {
				arrayInWhichToPutLabels[0] = findArgMaxOfMostCommonValArray( trainedDecisionTree );
				
			}
			
		}
		// CHECK TO SEE IF isLeafNode is toggled on
		if( trainedDecisionTree.isLeafNode ) {
			arrayInWhichToPutLabels[0] = findArgMaxOfMostCommonValArray( trainedDecisionTree);
		} else {
			double predictedLabel = exploreOneLevelInTree(featureVector, childToExplore); // use recursion to look through array list
			arrayInWhichToPutLabels[0] = predictedLabel;
		}
	}
	

	/*
	 * This function goes deeper and deeper into the tree, each time following the branch that
	 * our features array corresponds to for each and every feature, until we reach a leaf
	 */
	private double exploreOneLevelInTree( double[] features, Node subTree ) {
		globalNodeCounter++;
		double predictedLabel = -1;
		if( subTree.children == null ) {  // base case
			return subTree.label;
		} else {
			Node childToExplore = new Node();
			if( subTree.children != null ) {
				double featureValueFromMatrix = features[ subTree.attributesNumberThatWeSplitOn ];
				if( featureValueFromMatrix == Double.MAX_VALUE) {
					featureValueFromMatrix = classHistogramOfMostCommonValuesPerFeature[ trainedDecisionTree.attributesNumberThatWeSplitOn ];
				}
				if( (int)featureValueFromMatrix < subTree.children.size() ) {
					childToExplore = subTree.children.get((int)featureValueFromMatrix);
				} else {
					return findArgMaxOfMostCommonValArray( subTree);
				}				
			}
			
			// CHECK TO SEE IF isLeafNode is toggled on
			if( subTree.isLeafNode ) {
				 return findArgMaxOfMostCommonValArray( subTree);
			} else {
				predictedLabel = exploreOneLevelInTree(features, childToExplore); // use recursion to look through array list
			}
		}
		return predictedLabel; 
	}
	
	private Node makeTreeRec( Node currentNode, DataMatrix features, DataMatrix labels , int[] skipColsArray, int[] skipRowsArray) {
		currentNode.children = new ArrayList<Node>();
		int featuresLeftToSplitOn = 0;
		
		currentNode.mostCommonLabel = new int[ globalOriginalLabels.getValueCountForAttributeAtColumn(0) ];
		for( int feature = 0; feature < skipColsArray.length; feature++ ) {
			if( skipColsArray[feature] != 1) {
				featuresLeftToSplitOn++;
			}
		}
		Set<Double> labelValueCount = new HashSet<Double>();
		for( int row = 0; row < labels.getRowCount(); row++ ) {
			if( skipRowsArray[row] != 1) {
				labelValueCount.add( labels.getValueAt(row, 0) );
				currentNode.mostCommonLabel[ (int)globalOriginalLabels.getValueAt(row,0 ) ]++;
			}
		}
		// check to see if there are no more instances to use for future splits, I ran out of data
		
		if( labelValueCount.size() == 1 ) {		// if( all classes have the same label )
			Node leaf = new Node();
			leaf.label = labelValueCount.iterator().next(); // return a leaf with that label 
			return leaf;
		}
		else if( featuresLeftToSplitOn == 0 ) {   // there are no features left to test, BELOW IS THE BASELINE LEARNER
			
			int[] histogram = new int[ globalOriginalLabels.getValueCountForAttributeAtColumn(0) ]; 	
			for( int row = 0; row < features.getRowCount(); row++ ) {
				boolean rowNotApplicable = false;
				if( skipRowsArray[row] == 1 ) {
					rowNotApplicable = true;
				}
				if( rowNotApplicable == true ) { 
					continue;
				}
				int labelAtThisRow = (int) labels.getValueAt( row , 0 ); 
				histogram[labelAtThisRow]++;
			}	
			int majorityClass = -1;
			for( int i = 0; i < histogram.length; i++ ) {
				if( histogram[i] > majorityClass ) {
					majorityClass = histogram[i];
				}
			}
			Node majorityClassLeaf = new Node();
			majorityClassLeaf.label = majorityClass;
			return majorityClassLeaf; // return a leaf with the most common label
		} else {
			int attributeID = chooseFeatureToSplitOn ( features, labels, skipColsArray , skipRowsArray);
			
			if( attributeID == -9000 ) return currentNode; 
			currentNode.attributeWeSplitOn = globalOriginalFeatures.attributeNamesByColIndex.get(attributeID); 
			currentNode.attributesNumberThatWeSplitOn = attributeID;
			skipColsArray[attributeID] = 1;
			int[] newSkipColsArray = new int[ skipColsArray.length ]; 	// make a new skipRowsArray for every single branch
			for( int featureValue = 0; featureValue < globalOriginalFeatures.getValueCountForAttributeAtColumn(attributeID); featureValue++ ) { 
				for( int col = 0; col < newSkipColsArray.length; col++ ) {  
					newSkipColsArray[col] = skipColsArray[col];
				}
				Node subTree = new Node();
				int[] newSkipRowsArray = new int[ skipRowsArray.length ]; 	// make a new skipRowsArray for every single branch
				//int[] histogramMostCommonFeatureValue = new int[ features.valueCount(attributeID) ]; 
				int instanceLeftCounter = 0;
				for( int row = 0; row < newSkipRowsArray.length; row++ ) {  
					
					newSkipRowsArray[row] = skipRowsArray[row];
					if( features.getValueAt(row, attributeID) != featureValue) {
						newSkipRowsArray[row] = 1;	
					} 
					if( newSkipRowsArray[row] != 1) instanceLeftCounter++;
				}
				if( instanceLeftCounter == 0) {
					subTree.label = findArgMaxOfMostCommonValArray( currentNode);
					continue;
				}
				subTree = makeTreeRec( subTree , features, labels, newSkipColsArray, newSkipRowsArray ); // recursively call the algorithm with Sf, to compute the gain relative to the current set of examples
									
				currentNode.children.add( subTree );
			}
		}
		return currentNode;
	}
	
	/*
	 * We MAXIMIZE GAIN BY MINIMIZING featureInfo/ featureEntropy
	 * We take the attribute that will minimize the entropy of the feature we split on.
	 */
	private int chooseFeatureToSplitOn( DataMatrix features, DataMatrix labels , int[] skipColsArray, int[] skipRowsArray) {
		
		int attributeID = -1; // JUST ARBITRARY IMPOSSIBLE VALUE TO INITIALIZE
		double minFeatureEntropy = Double.MAX_VALUE;	// maximumEntropy
		
		for( int feature = 0; feature < features.getColCount(); feature++ ) {
			boolean treeAlreadyPartitionedOnThisFeature = false;
			if( skipColsArray[feature] == 1 ) {
				treeAlreadyPartitionedOnThisFeature = true;
			}
			if( treeAlreadyPartitionedOnThisFeature == true ) {
				continue;
			}
			double currentFeatureEntropy = findEntropyOfParticularAttribute(features, labels, feature , skipRowsArray); 
			if( currentFeatureEntropy < minFeatureEntropy ) {
				attributeID  = feature;
				minFeatureEntropy = currentFeatureEntropy;
			}
		}
		
	
		return attributeID;
	}
	
	private double findEntropyOfParticularAttribute( DataMatrix features, DataMatrix labels, int attributeID, int[] skipRowsArray) {
		
		double score = 0;
		int totalNumInstancesForThisAttribute = 0;  
		for( int specificFeatureValue = 0; specificFeatureValue < globalOriginalFeatures.getValueCountForAttributeAtColumn(attributeID); specificFeatureValue++ ) {
			double entropyForSpecificFeatureValue = 0;
			double[] histogram = new double[ globalOriginalLabels.getValueCountForAttributeAtColumn(0) ]; 
			int numOfInstancesForThisFeatureValue = 0; 
			
			for( int row = 0; row < features.getRowCount(); row++ ) {
				boolean rowNotApplicable = false;
				if( skipRowsArray[row] == 1 ) {
					rowNotApplicable = true;  	
				}
				if( rowNotApplicable == true ) {
					continue;
				}
				if( features.getValueAt(row, attributeID) == specificFeatureValue ) {
					numOfInstancesForThisFeatureValue++;
					int labelAtThisRow = (int) labels.getValueAt( row , 0 ); 
						histogram[labelAtThisRow]++;
				}
			}		
			totalNumInstancesForThisAttribute += numOfInstancesForThisFeatureValue;
			for( int histogramIndex = 0; histogramIndex < histogram.length; histogramIndex++ ) {
				if( numOfInstancesForThisFeatureValue != 0 ) { 
					histogram[histogramIndex] /= numOfInstancesForThisFeatureValue ; 			
				}
				if( histogram[histogramIndex] != 0) {
					entropyForSpecificFeatureValue += ( histogram[histogramIndex] * (Math.log( histogram[histogramIndex] ) / Math.log(2) ) );
				}
			}
			score += ( entropyForSpecificFeatureValue * numOfInstancesForThisFeatureValue);	
		}
		score /= ( -1 * totalNumInstancesForThisAttribute );
		return score; 	
	}
	

	void createStackOfNodesFromBottomUp() {
		Stack stackOfNodesFromLeavesToRoot = new Stack(); //initialize stack
		Queue<Node> myQueue = new LinkedList<Node>();// initialize a queue
		myQueue.add( trainedDecisionTree ); // add the root node to the queue
		while ( myQueue.size() > 0 ) { // while (!myQueue.isEmpty())
			Node n = myQueue.remove(); // takes the first element off of the queue, pop
			ArrayList<Node> childrenToAdd = n.children;
			if( childrenToAdd != null) {
				myQueue.addAll( childrenToAdd ); //n.children );
			}
			stackOfNodesFromLeavesToRoot.push( n );
		}
		classStackOfNodesFromLeavesToRoot = stackOfNodesFromLeavesToRoot;
	}

	void pruneTheDecisionTreeAndMeasureResults( DataMatrix featuresValidationSet, DataMatrix labelsValidationSet ) throws Exception {
		double baselineValidationSetAccuracy = this.measurePredictiveAccuracy( featuresValidationSet,labelsValidationSet, null );
		System.out.println( "THIS IS BASELINE VALID SET ACCURACY " + baselineValidationSetAccuracy );
		while( !classStackOfNodesFromLeavesToRoot.isEmpty() ) {
			Node nodeToBeConvertedToLeaf = (Node)classStackOfNodesFromLeavesToRoot.pop(); 
			
			if( this.measurePredictiveAccuracy( featuresValidationSet,labelsValidationSet, null ) < baselineValidationSetAccuracy ) { 
				nodeToBeConvertedToLeaf.isLeafNode = false;
			} else {
				double newBetterAccuracy = this.measurePredictiveAccuracy( featuresValidationSet,labelsValidationSet, null ); 
				baselineValidationSetAccuracy = newBetterAccuracy;
			}
		}
	}
	

	 int findArgMaxOfMostCommonValArray( Node subTree) {
		 int maxFrequency = 0;
		int mostCommonWinner = -1;
		for(int i = 0; i < subTree.mostCommonLabel.length ; i++ ) {
			if( subTree.mostCommonLabel[i] > maxFrequency ) {
				maxFrequency = subTree.mostCommonLabel[i];
				mostCommonWinner = i;
			}
		}
		return mostCommonWinner;
	 }
	 
	 void countNodesInPrunedTree(Node decisionTree) {
		 	Stack stackOfNodesFromLeavesToRoot = new Stack(); //initialize stack
			Queue<Node> myQueue = new LinkedList<Node>();// initialize a queue
			myQueue.add( decisionTree ); // add the root node to the queue
			while ( myQueue.size() > 0 ) { // while (!myQueue.isEmpty())
				Node n = myQueue.remove(); // takes the first element off of the queue, pop
				ArrayList<Node> childrenToAdd = n.children;
				if( (childrenToAdd != null) && (n.isLeafNode==false) ) {
					myQueue.addAll( childrenToAdd ); //n.children );
				}
				stackOfNodesFromLeavesToRoot.push( n );
			}
			System.out.println( "This many nodes in the pruned tree" + stackOfNodesFromLeavesToRoot.size() );
	 }
}