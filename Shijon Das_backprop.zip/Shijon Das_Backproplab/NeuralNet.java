import java.util.ArrayList;
import java.util.Random;
import java.lang.*;
import java.util.*;

public class NeuralNet extends SupervisedLearner {
	
	private int numHiddenLayers = 1;
	private int[] numNodesPerHiddenLayer = {128}; 
	private ArrayList<double[][]> arrayListOfEachLayersWeightMatrices;
	private ArrayList<double[][]> changeInWeightMatricesForEveryLayer;
	private ArrayList<double[][]> temporaryStashChangeInWeightMatricesForEveryLayer;
	private ArrayList<double[][]> previousChangeInWeightMatricesForEachLayer;
	private ArrayList<double[]> biasWeightsAcrossAllLayers;
	private ArrayList<double[]> changeInBiasArrayForEveryLayer;
	private ArrayList<double[]> previousBiasChangeInWeightsAcrossAllLayers;
	private ArrayList<double[]> temporarilyStashedChangeInBiasWeightsAcrossAllLayers;
	private ArrayList<double[]> arrayListOfEachLayersDeltaArray;
	private ArrayList<double[]> storedFNetForEachLayer; // f_net is the output that is fed into the next layer
		// we store f_net for each node
	private double learningRate = 0.01;
	private double momentum = 0.9;
	private double validationSetPercentageOfData = 0.80;
	private double[] globalStoredOutputNodeFNetValues;
	private double[] globalStoredOutputNodeTargetValues;
	private Random rand;
	
	public NeuralNet(Random rand) {
		this.rand = rand;
	}

	
	public void train(DataMatrix featuresOnlyDataMatrix, DataMatrix labelsOnlyDataMatrix) throws Exception {
		
		double[] recentAccuracies = new double[5];
		int currentAccuracyIndex = 0; 
		double currentAccuracy = 0;
		
		Random rand = new Random();
		// SHUFFLE labels, features together
		featuresOnlyDataMatrix.shuffleRowOrderWithBuddyMatrix(rand, labelsOnlyDataMatrix);
		
		// need to map 0,1, or 2 to the three dimensional vectors, DO N-OF-K-ENCODING FOR THE BACKPROPAGATION
		DataMatrix newNOfKLabelsMatrix = new DataMatrix();
		newNOfKLabelsMatrix.setSize( labelsOnlyDataMatrix.getRowCount(), labelsOnlyDataMatrix.getValueCountForAttributeAtColumn(0) ); 
		for( int row = 0; row < newNOfKLabelsMatrix.getRowCount(); row++) { // for each instance
			for( int k = 0; k < labelsOnlyDataMatrix.getValueCountForAttributeAtColumn(0); k++ ) {
				if( labelsOnlyDataMatrix.getValueAt(row, 0) == k) {
					for( int m = 0; m < labelsOnlyDataMatrix.getValueCountForAttributeAtColumn(0); m++ ) {
						newNOfKLabelsMatrix.setValue( row, m, 0 );
					}
					newNOfKLabelsMatrix.setValue( row, k, 1 );
				}	
			}
		}
		labelsOnlyDataMatrix = newNOfKLabelsMatrix;
		
		
		int numRowsToGetIntoTrainingSet = (int)(featuresOnlyDataMatrix.getRowCount() * validationSetPercentageOfData );
		
		DataMatrix featuresForTrainingTrimmed = new DataMatrix();
		featuresForTrainingTrimmed.setSize( numRowsToGetIntoTrainingSet , featuresOnlyDataMatrix.getColCount() );
		DataMatrix featuresValidationSet = new DataMatrix();
		featuresValidationSet.setSize( featuresOnlyDataMatrix.getRowCount() - numRowsToGetIntoTrainingSet, featuresOnlyDataMatrix.getColCount() );
		
		DataMatrix labelsForTrainingTrimmed = new DataMatrix();
		labelsForTrainingTrimmed.setSize( numRowsToGetIntoTrainingSet , labelsOnlyDataMatrix.getColCount() );
		DataMatrix labelsValidationSet = new DataMatrix();
		labelsValidationSet.setSize( featuresOnlyDataMatrix.getRowCount() - numRowsToGetIntoTrainingSet, labelsOnlyDataMatrix.getColCount() );
		
		// LOOP THROUGH AND PUT MOST OF FEATURES INTO featuresForTrainingTrimmed
		for( int row = 0; row < featuresOnlyDataMatrix.getRowCount() ; row++ ) {
			for( int col = 0; col < featuresOnlyDataMatrix.getColCount() ; col++ ) {
				if( row < numRowsToGetIntoTrainingSet ) {
					featuresForTrainingTrimmed.setValue( row, col, featuresOnlyDataMatrix.getValueAt(row, col) );
				} else {
					featuresValidationSet.setValue( row - numRowsToGetIntoTrainingSet , col  , featuresOnlyDataMatrix.getValueAt(row, col) );
				}
			}
		}
		
		// LOOP THROUGH AND PUT MOST OF FEATURES INTO featuresForTrainingTrimmed
		for( int row = 0; row < labelsOnlyDataMatrix.getRowCount() ; row++ ) {
			for( int col = 0; col < labelsOnlyDataMatrix.getColCount() ; col++ ) {
				if( row < numRowsToGetIntoTrainingSet ) {
					labelsForTrainingTrimmed.setValue( row, col, labelsOnlyDataMatrix.getValueAt(row, col) );
				} else {
					labelsValidationSet.setValue( row - numRowsToGetIntoTrainingSet , col  , labelsOnlyDataMatrix.getValueAt(row, col) );
				}
			}
		}
		
		featuresOnlyDataMatrix = featuresForTrainingTrimmed;
		labelsOnlyDataMatrix = labelsForTrainingTrimmed;
		// LOOP THROUGH AND PUT LEFTOVER PORTION OF FEATURES INTO validationSet
		arrayListOfEachLayersWeightMatrices = new ArrayList<double[][]>();
		
		for( int i = 0; i < numHiddenLayers + 1 ; i++ ) { // each layer
			double[][] specificLayersWeightMatrix;
			if( i == 0 ) { // first hidden layer (Each layer owns its own weights)
				specificLayersWeightMatrix = new double[ featuresOnlyDataMatrix.getColCount() ][ numNodesPerHiddenLayer[i] ] ; // INPUTS are the rows
			} else if( i == numHiddenLayers) {
				specificLayersWeightMatrix = new double[ numNodesPerHiddenLayer[ i-1 ] ][ labelsOnlyDataMatrix.getColCount() ] ; // OUTPUTS ARE THE COLUMNS
			} else {
				specificLayersWeightMatrix = new double[ numNodesPerHiddenLayer[i - 1] ][ numNodesPerHiddenLayer[ i ] ] ;
			}
			arrayListOfEachLayersWeightMatrices.add(specificLayersWeightMatrix ) ;
		}
		
		changeInWeightMatricesForEveryLayer = new ArrayList<double[][]>();
		
		for( int i = 0; i < numHiddenLayers + 1 ; i++ ) { // each layer
			double[][] specificLayersWeightMatrix;
			if( i == 0 ) { // first hidden layer (Each layer owns its own weights)
				specificLayersWeightMatrix = new double[ featuresOnlyDataMatrix.getColCount() ][ numNodesPerHiddenLayer[i] ] ; // INPUTS are the rows
			} else if( i == numHiddenLayers) {
				specificLayersWeightMatrix = new double[ numNodesPerHiddenLayer[ i-1 ] ][ labelsOnlyDataMatrix.getColCount() ] ; // OUTPUTS ARE THE COLUMNS
			} else {
				specificLayersWeightMatrix = new double[ numNodesPerHiddenLayer[i - 1] ][ numNodesPerHiddenLayer[ i ] ] ;
			}
			changeInWeightMatricesForEveryLayer.add(specificLayersWeightMatrix ) ;
		}
		
		
		// allocate space/ initialize the previous change in weights that we'll use for momentum
		temporaryStashChangeInWeightMatricesForEveryLayer = new ArrayList<double[][]>();
		
		for( int i = 0; i < numHiddenLayers + 1 ; i++ ) { // each layer
			double[][] specificLayersWeightMatrix;
			if( i == 0 ) { // first hidden layer (Each layer owns its own weights)
				specificLayersWeightMatrix = new double[ featuresOnlyDataMatrix.getColCount() ][ numNodesPerHiddenLayer[i] ] ; // INPUTS are the rows
			} else if( i == numHiddenLayers) {
				specificLayersWeightMatrix = new double[ numNodesPerHiddenLayer[ i-1 ] ][ labelsOnlyDataMatrix.getColCount() ] ; // OUTPUTS ARE THE COLUMNS
			} else {
				specificLayersWeightMatrix = new double[ numNodesPerHiddenLayer[i - 1] ][ numNodesPerHiddenLayer[ i ] ] ;
			}
			temporaryStashChangeInWeightMatricesForEveryLayer.add(specificLayersWeightMatrix ) ;
		}
		
		// ALLOCATE SPACE FOR DELTA ( INTERMEDIATE VALUES THAT WE USE TO UPDATE THE WEIGHTS)
		
		arrayListOfEachLayersDeltaArray = new ArrayList<double[]>();
		//  EACH LAYER HAS AN ARRAY OF DELTA VALUES
		for( int i = 0; i < numHiddenLayers + 2 ; i++ ) {
			double[] specificLayersDeltaArray;
			if( i == 0 ) { // first hidden layer (Each layer owns its own weights)
				specificLayersDeltaArray = new double[ featuresOnlyDataMatrix.getColCount() ]; // INPUTS are the rows
			} else if( i == (numHiddenLayers + 1) ) {
				
				specificLayersDeltaArray = new double[ labelsOnlyDataMatrix.getColCount() ]; 
			} else {
				specificLayersDeltaArray = new double[ numNodesPerHiddenLayer[i - 1] ] ; 
			}
			arrayListOfEachLayersDeltaArray.add( specificLayersDeltaArray ) ;
		}
		
		previousChangeInWeightMatricesForEachLayer = new ArrayList<double[][]>();
		
		for( int i = 0; i < numHiddenLayers + 1 ; i++ ) { // each layer
			double[][] specificLayersWeightMatrix;
			if( i == 0 ) { // first hidden layer (Each layer owns its own weights)
				specificLayersWeightMatrix = new double[ featuresOnlyDataMatrix.getColCount() ][ numNodesPerHiddenLayer[i] ] ; // INPUTS are the rows
			} else if( i == numHiddenLayers) {
				specificLayersWeightMatrix = new double[ numNodesPerHiddenLayer[ i-1 ] ][ labelsOnlyDataMatrix.getColCount() ] ; // OUTPUTS ARE THE COLUMNS
			} else {
				specificLayersWeightMatrix = new double[ numNodesPerHiddenLayer[i - 1] ][ numNodesPerHiddenLayer[ i ] ] ;
			}
			previousChangeInWeightMatricesForEachLayer.add(specificLayersWeightMatrix ) ;
		}
		
		// INITIALIZE ALL OF PREVIOUS DELTA VALUES TO 0 [ THIS IS DONE AUTOMATICALLY, CAN DELETE ALL OF THIS CODE ]
		
		// initialize all weights randomly ( small random weights with 0 mean)
		
		double[][] currentLayersWeightMatrix;
		for( int i = 0; i< numNodesPerHiddenLayer.length + 1 ; i++ ) { // scroll across each layer
		
			currentLayersWeightMatrix = arrayListOfEachLayersWeightMatrices.get(i) ;
			for( int j = 0; j < currentLayersWeightMatrix.length ; j++ ) {
				for( int k = 0; k < currentLayersWeightMatrix[j].length; k++ ) {
					currentLayersWeightMatrix[j][k] =  ( 2 * rand.nextDouble() ) - 1 ;
				}
			}
		}
		// PUT ALL BIAS WEIGHTS INTO ARRAYLIST (ONE ARRAY FOR EACH LAYER'S BIAS WEIGHTS)
		biasWeightsAcrossAllLayers = new ArrayList<double[]>();
		for( int i = 0; i< numHiddenLayers + 1; i++) {
			if( i < numHiddenLayers) {
				double[] biasArrayToBeAdded = new double[ numNodesPerHiddenLayer[i] ];
				biasWeightsAcrossAllLayers.add( biasArrayToBeAdded );
			} else {
				double[] biasArrayForOutputNodesToBeAdded = new double[ labelsOnlyDataMatrix.getColCount() ];
				biasWeightsAcrossAllLayers.add( biasArrayForOutputNodesToBeAdded );
			}
		}
		
		double[] currentBiasLayersWeightArray;
		for( int i = 0; i< numNodesPerHiddenLayer.length + 1 ; i++ ) { // scroll across each layer
			currentBiasLayersWeightArray = biasWeightsAcrossAllLayers.get(i) ;
			for( int j = 0; j < currentBiasLayersWeightArray.length ; j++ ) {
				
				currentBiasLayersWeightArray[j] =  ( 2 * rand.nextDouble() ) - 1 ;
			}
		}
		
		//We'll need to store the previous bias weights
		previousBiasChangeInWeightsAcrossAllLayers = new ArrayList<double[]>();
		for( int i = 0; i< numHiddenLayers + 1; i++) {
			if( i < numHiddenLayers) {
				double[] biasArrayToBeAdded = new double[ numNodesPerHiddenLayer[i] ];
				previousBiasChangeInWeightsAcrossAllLayers.add( biasArrayToBeAdded );
			} else {
				double[] biasArrayForOutputNodesToBeAdded = new double[ labelsOnlyDataMatrix.getColCount() ];
				previousBiasChangeInWeightsAcrossAllLayers.add( biasArrayForOutputNodesToBeAdded );
			}
		}
		
		// temporarily stashed bias weights across all layers
		temporarilyStashedChangeInBiasWeightsAcrossAllLayers = new ArrayList<double[]>();
		for( int i = 0; i< numHiddenLayers + 1; i++) {
			if( i < numHiddenLayers) {
				double[] biasArrayToBeAdded = new double[ numNodesPerHiddenLayer[i] ];
				temporarilyStashedChangeInBiasWeightsAcrossAllLayers.add( biasArrayToBeAdded );
			} else {
				double[] biasArrayForOutputNodesToBeAdded = new double[ labelsOnlyDataMatrix.getColCount() ];
				temporarilyStashedChangeInBiasWeightsAcrossAllLayers.add( biasArrayForOutputNodesToBeAdded );
			}
		}
		
		changeInBiasArrayForEveryLayer = new ArrayList<double[]>();
		for( int i = 0; i< numHiddenLayers + 1; i++) {
			if( i < numHiddenLayers) {
				double[] biasArrayToBeAdded = new double[ numNodesPerHiddenLayer[i] ];
				changeInBiasArrayForEveryLayer.add( biasArrayToBeAdded );
			} else {
				double[] biasArrayForOutputNodesToBeAdded = new double[ labelsOnlyDataMatrix.getColCount() ];
				changeInBiasArrayForEveryLayer.add( biasArrayForOutputNodesToBeAdded );
			}
		}

		
		
		storedFNetForEachLayer = new ArrayList<double[]>(); // f_net is the output that is fed into the next layer
		for( int i = 0; i < numHiddenLayers + 2; i++ ) { // WE HAVE ONE MORE layer of fnet( consider inputs as fnet)
			double[] thisLayersFNetValues;
			if( i == 0) {
				thisLayersFNetValues = new double[ featuresOnlyDataMatrix.getColCount() ]; // FIND OUT # NODES AT EACH LEVEL
			} else if (i == numHiddenLayers + 1 ) { // OR IS IT +1
				thisLayersFNetValues = new double[ labelsOnlyDataMatrix.getColCount() ]; // FIND OUT # NODES AT EACH LEVEL
			} else {
				thisLayersFNetValues = new double[ numNodesPerHiddenLayer[ i-1 ] ]; // FIND OUT # NODES AT EACH LEVEL
			}
			storedFNetForEachLayer.add( thisLayersFNetValues );
		}
		
		
		double netValAtNode = 0;
		double fOfNetValAtNode = 0;
		for( int epoch = 0; epoch < 15000 ; epoch++ ) { // For each epoch, cap it at 10000, we want to avoid infinite loop
			System.out.println("---Epoch " + epoch + "---");
			for ( int instance = 0; instance < featuresOnlyDataMatrix.getRowCount() ; instance++ ) { // later we will swap this DataMatrix for featuresForTrainingTrimmed

				for( int layer = 0; layer < numHiddenLayers + 2 ; layer++ ) { // HERE LAYER DENOTES HIDDEN LAYER
					if( layer == 0) {
						storedFNetForEachLayer.set( layer,  Arrays.copyOf( featuresOnlyDataMatrix.getRow(instance) , featuresOnlyDataMatrix.getRow(0).length ) );
						continue;
					}
					double[] thisLayersFNetValues = storedFNetForEachLayer.get(layer); 	
					for( int node = 0; node < storedFNetForEachLayer.get(layer).length ; node++ ) {
						netValAtNode = 0;						
						for( int colInInputVector = 0; colInInputVector< storedFNetForEachLayer.get(layer-1).length ; colInInputVector++ ) {					
							netValAtNode +=  ( storedFNetForEachLayer.get(layer-1)[colInInputVector] *  arrayListOfEachLayersWeightMatrices.get(layer-1)[colInInputVector ][ node  ]) ;
						}
						netValAtNode += ( biasWeightsAcrossAllLayers.get(layer-1)[ node ] );
						if( netValAtNode < 0) { // make special function
							fOfNetValAtNode = (1 / (1 + Math.pow( Math.E, (-1 * netValAtNode ) ) ) );							
						} else { // normal
							fOfNetValAtNode = (1 / (1 + (1 / (Math.pow( Math.E, ( netValAtNode ) ) ) ) ) ); // if it was positive, then we raise to neg exponent
						}
						thisLayersFNetValues[node] = fOfNetValAtNode; 	// stick it into the object
					}
					storedFNetForEachLayer.set( layer, thisLayersFNetValues ); // or if we are editing object, this is not even necessary DOUBLE CHECK
				}

				for( int layer = numHiddenLayers + 1; layer > 0; layer-- ) { // ACROSS EACH LAYER BACKWARD 
					if( layer == numHiddenLayers + 1) { // THIS IS AN OUTPUT LAYER
						for( int node = 0; node < labelsOnlyDataMatrix.getColCount(); node++ ) {
							double deltaArrayForThisLayer[] = arrayListOfEachLayersDeltaArray.get(layer);
							deltaArrayForThisLayer[node] =(  ( labelsOnlyDataMatrix.getValueAt(instance, node) - storedFNetForEachLayer.get(layer)[node] ) * (storedFNetForEachLayer.get(layer)[node]) * 
								(1 - (storedFNetForEachLayer.get(layer)[node]) ) );
							// should automatically be set since we get the objects address from heap memory, and change it
							for( int inputToThisNode = 0; inputToThisNode < numNodesPerHiddenLayer[layer-2] + 1 ; inputToThisNode++ ) {
								double changeInWeightBetweenIJ = 0;
								if( inputToThisNode == numNodesPerHiddenLayer[layer-2] ) { // this is a bias node
									
									changeInWeightBetweenIJ = ( learningRate * 1 * arrayListOfEachLayersDeltaArray.get(layer)[node] ); // NEED TO ADD STUFF FOR MOMENTUM
									double[] thisLayersBiasWeights = changeInBiasArrayForEveryLayer.get(layer-1); // NEED TO ADD STUFF FOR MOMENTUM
									thisLayersBiasWeights[node] = ( changeInWeightBetweenIJ); // NEED TO ADD STUFF FOR MOMENTUM
								} else {
								
									changeInWeightBetweenIJ = ( learningRate * storedFNetForEachLayer.get(layer-1)[inputToThisNode] * arrayListOfEachLayersDeltaArray.get(layer)[node]);
									double[][] changeInWeightsMatrixForThisLayer = changeInWeightMatricesForEveryLayer.get(layer-1);
									changeInWeightsMatrixForThisLayer[inputToThisNode][node] = changeInWeightBetweenIJ;
								}
							}
						}
					} else {
						
						for( int node = 0; node < numNodesPerHiddenLayer[layer-1] + 1 ; node++ ) {  
							double deltaArrayForThisLayer[] = arrayListOfEachLayersDeltaArray.get(layer);
							
							if( node == numNodesPerHiddenLayer[layer-1] ) { // this is a bias node
							} else {  
								double summedOutgoingWeightsCrossOutputDelta = 0;
								
								for( int outgoingEdgeToOutgoingNode = 0; outgoingEdgeToOutgoingNode< arrayListOfEachLayersDeltaArray.get(layer+1).length ; outgoingEdgeToOutgoingNode++ ) {					
									summedOutgoingWeightsCrossOutputDelta +=  ( arrayListOfEachLayersDeltaArray.get(layer+1)[outgoingEdgeToOutgoingNode] *  
											arrayListOfEachLayersWeightMatrices.get(layer)[ node ][outgoingEdgeToOutgoingNode ]) ;
									
								}
								
								deltaArrayForThisLayer[node] =( ( summedOutgoingWeightsCrossOutputDelta ) * (storedFNetForEachLayer.get(layer)[node]) * 
									(1 - (storedFNetForEachLayer.get(layer)[node]) ) );
								// should automatically be set since we get the objects address from heap memory, and change it
								
								if( layer == 1) {
									// need a for loop across the neural net's input nodes
									for( int inputToTheNeuralNet = 0; inputToTheNeuralNet < featuresOnlyDataMatrix.getColCount() + 1; inputToTheNeuralNet++ ) {
										double changeInWeightBetweenIJ = 0;
										if( inputToTheNeuralNet == featuresOnlyDataMatrix.getColCount() ) { // then we know that this is our bias node
											
											changeInWeightBetweenIJ = ( learningRate * 1 * arrayListOfEachLayersDeltaArray.get(layer)[node] ); // NEED TO ADD STUFF FOR MOMENTUM
											double[] thisLayersBiasWeights = changeInBiasArrayForEveryLayer.get(layer-1); // NEED TO ADD STUFF FOR MOMENTUM
											thisLayersBiasWeights[node] = ( changeInWeightBetweenIJ); // NEED TO ADD STUFF FOR MOMENTUM
											
										} else {
											
											changeInWeightBetweenIJ = ( learningRate * storedFNetForEachLayer.get(layer-1)[inputToTheNeuralNet] * arrayListOfEachLayersDeltaArray.get(layer)[node]);
											double[][] changeInWeightsMatrixForThisLayer = changeInWeightMatricesForEveryLayer.get(layer-1);
											changeInWeightsMatrixForThisLayer[inputToTheNeuralNet][node] = changeInWeightBetweenIJ;
										}
									}
								} else {
									for( int inputToThisNode = 0; inputToThisNode < numNodesPerHiddenLayer[layer-2] + 1 ; inputToThisNode++ ) {
										double changeInWeightBetweenIJ = 0;
										if( inputToThisNode == numNodesPerHiddenLayer[layer-2] ) { // this is a bias node
											
											changeInWeightBetweenIJ = ( learningRate * 1 * arrayListOfEachLayersDeltaArray.get(layer)[node] ); // NEED TO ADD STUFF FOR MOMENTUM
											double[] thisLayersBiasWeights = changeInBiasArrayForEveryLayer.get(layer-1); // NEED TO ADD STUFF FOR MOMENTUM
											thisLayersBiasWeights[node] = ( changeInWeightBetweenIJ); // NEED TO ADD STUFF FOR MOMENTUM
											
										} else {
											
											changeInWeightBetweenIJ = ( learningRate * storedFNetForEachLayer.get(layer-1)[inputToThisNode] * arrayListOfEachLayersDeltaArray.get(layer)[node]);
											double[][] changeInWeightsMatrixForThisLayer = changeInWeightMatricesForEveryLayer.get(layer-1);
											changeInWeightsMatrixForThisLayer[inputToThisNode][node] = changeInWeightBetweenIJ;
										}
									}
								}
							}
						}
					}					
				}	
				
				for( int w = 0; w < previousBiasChangeInWeightsAcrossAllLayers.size(); w++ ) {
					for( int y = 0; y < previousBiasChangeInWeightsAcrossAllLayers.get(w).length; y++ ) {
						double currentChangeInWeightVal = changeInBiasArrayForEveryLayer.get(w)[y];
						double[] fullBiasWeightList = biasWeightsAcrossAllLayers.get(w);
						double previousXYCoordInBiasWeightMatrix = previousBiasChangeInWeightsAcrossAllLayers.get(w)[y];
						double thisIsTheWeightChangeIncludingMomentum = ( currentChangeInWeightVal + (momentum*previousXYCoordInBiasWeightMatrix)) ;
						fullBiasWeightList[y] += thisIsTheWeightChangeIncludingMomentum;
						double[] arrayOfPreviousBiases = previousBiasChangeInWeightsAcrossAllLayers.get(w);
						arrayOfPreviousBiases[y] = thisIsTheWeightChangeIncludingMomentum;
					}
				} 
				
				// GET NEW CHANGE IN WEIGHT THANKS TO MOMENTUM, PLACE IN PREVIOUS SPOT
				
				// We update the weights ( by adding the changes in weights to the weight matrices) after every layer has been processed
				for( int w = 0; w < arrayListOfEachLayersWeightMatrices.size(); w++ ) {
					for( int y = 0; y < arrayListOfEachLayersWeightMatrices.get(w).length; y++ ) {
						for( int z = 0; z < arrayListOfEachLayersWeightMatrices.get(w)[y].length ; z++ ) {
							double currentXYCoordInMatrix = changeInWeightMatricesForEveryLayer.get(w)[y][z];
							double[] fullWeightListForLayer = arrayListOfEachLayersWeightMatrices.get(w)[y];
							
							double previousXYCoordInChangeInWeightMatrix = previousChangeInWeightMatricesForEachLayer.get(w)[y][z];
							double thisIsTheWeightChangeIncludingMomentum = (currentXYCoordInMatrix + ( previousXYCoordInChangeInWeightMatrix*momentum) );
							fullWeightListForLayer[z] += thisIsTheWeightChangeIncludingMomentum;
							double[][] arrayOfPreviousBiases = previousChangeInWeightMatricesForEachLayer.get(w);
							arrayOfPreviousBiases[y][z] = thisIsTheWeightChangeIncludingMomentum;
						}
					}
				} 
								
			}
			
			//if( STOPPING CRITERIA MET ) {  // HAVE TO USE THE VALIDATION SET THIS TIME FOR THE STOPPING CRITERION
			currentAccuracy = calculateMSEOnValidationSet( featuresValidationSet , labelsValidationSet );
		

			System.out.println(" Current MSE on validation and training epoch # " + epoch + " is: " + currentAccuracy + ","+calculateMSEOnTrainingSet(featuresOnlyDataMatrix,labelsOnlyDataMatrix)); 

			currentAccuracyIndex++;
			recentAccuracies[ currentAccuracyIndex % 5 ] = currentAccuracy;
			double sumAccuracies = 0;
			if( currentAccuracyIndex > 5) {
				for( int i=0; i< recentAccuracies.length ; i++ ) {
					sumAccuracies += Math.abs( recentAccuracies[ currentAccuracyIndex % 5 ] - recentAccuracies[i] );
				}
				if( sumAccuracies < 0.01 ) { // we only stop training when measureAccuracy after 5 epochs does not increase by 0.01
					break ;
				}
			}

			// In theory, it would be wise here to go back to the old best weights because now we're already overfitting if the stopping criterion is met
			featuresOnlyDataMatrix.shuffleRowOrderWithBuddyMatrix(rand, labelsOnlyDataMatrix); // MUST SHUFFLE DATA ROWS AFTER EACH EPOCH,labels is the buddy DataMatrix
		
		}
		return;
	}

	public void predictInstanceLabelsFromFeatures(double[] featureVector, double[] arrayInWhichToPutLabels) throws Exception {
		
		double netValAtNode = 0;
		double fOfNetValAtNode = 0;

		
		for( int layer = 0; layer < numHiddenLayers + 2 ; layer++ ) { // HERE LAYER DENOTES HIDDEN LAYER
			if( layer == 0) {
				storedFNetForEachLayer.set( layer,  Arrays.copyOf( featureVector , featureVector.length ) );
				continue;
			}
			double[] thisLayersFNetValues = storedFNetForEachLayer.get(layer); 	// make a new array of doubles  CAN I PLEASE DELETE THIS LINE OF CODE
			for( int node = 0; node < storedFNetForEachLayer.get(layer).length ; node++ ) {
				netValAtNode = 0;						
				// FIND THE CROSS PRODUCT;
				// use a for loop to multiply each col of weights vector by each col of outputsFromPreviousLayer
				for( int colInInputVector = 0; colInInputVector< storedFNetForEachLayer.get(layer-1).length ; colInInputVector++ ) {					
					netValAtNode +=  ( storedFNetForEachLayer.get(layer-1)[colInInputVector] *  arrayListOfEachLayersWeightMatrices.get(layer-1)[colInInputVector ][ node  ]) ;
				}
				netValAtNode += ( biasWeightsAcrossAllLayers.get(layer-1)[ node ] );
				if( netValAtNode < 0) { // make special function
					fOfNetValAtNode = (1 / (1 + Math.pow( Math.E, (-1 * netValAtNode ) ) ) );							
				} else { // normal
					fOfNetValAtNode = (1 / (1 + (1 / (Math.pow( Math.E, ( netValAtNode ) ) ) ) ) ); // if it was positive, then we raise to neg exponent
				}
				thisLayersFNetValues[node] = fOfNetValAtNode; 	// stick it into the object
				
			}
			storedFNetForEachLayer.set( layer, thisLayersFNetValues ); // or if we are editing object, this is not even necessary DOUBLE CHECK
		}
		double maxPredictedFOfNetVal = -999999;
		int predictedClass = 0;
		double[] storedOutputNodeFNetValues = new double[ storedFNetForEachLayer.get(numHiddenLayers + 1 ).length ];
		double[] storedOutputNodeTargetValues = new double[ storedFNetForEachLayer.get(numHiddenLayers + 1 ).length ];
		
		for(int i = 0; i < storedFNetForEachLayer.get(numHiddenLayers + 1 ).length ; i++ ) {
			if( arrayInWhichToPutLabels.length > 1) {
				storedOutputNodeFNetValues[i] = storedFNetForEachLayer.get(numHiddenLayers + 1 )[i];
				storedOutputNodeTargetValues[i] = arrayInWhichToPutLabels[i];  			// time to go ahead and save what we had at each output node
			}
			if( storedFNetForEachLayer.get(numHiddenLayers + 1 )[i] > maxPredictedFOfNetVal ) {
				predictedClass = i;
				maxPredictedFOfNetVal = storedFNetForEachLayer.get(numHiddenLayers + 1 )[i];
			}
		}
		arrayInWhichToPutLabels[0] = predictedClass;
		globalStoredOutputNodeFNetValues = storedOutputNodeFNetValues;
		globalStoredOutputNodeTargetValues = storedOutputNodeTargetValues;
	}
	double calculateMSEOnValidationSet(DataMatrix featuresValidationSet, DataMatrix labelsValidationSet ) throws Exception {
		
		double sumSquaredError = 0;
		
		for( int instance = 0; instance < featuresValidationSet.getRowCount() ; instance++ ) {
			double errorAcrossOutputNodes = 0;
			double[] predictedLabel = labelsValidationSet.getRow( instance); // this is the target
			predictInstanceLabelsFromFeatures( featuresValidationSet.getRow(instance), labelsValidationSet.getRow(instance) );
			for( int col = 0; col < globalStoredOutputNodeFNetValues.length; col++ ) {
				errorAcrossOutputNodes += ( globalStoredOutputNodeTargetValues[col] - globalStoredOutputNodeFNetValues[col] );
			}
			sumSquaredError += (errorAcrossOutputNodes * errorAcrossOutputNodes );
		}
		
		double MSE = ( sumSquaredError / (featuresValidationSet.getRowCount() * globalStoredOutputNodeFNetValues.length) );
		
		return MSE;
	}
	double calculateMSEOnTrainingSet(DataMatrix featuresOnlyDataMatrix, DataMatrix labelsOnlyDataMatrix) throws Exception {
	    double sumSquaredError = 0;

	    for (int instance = 0; instance < featuresOnlyDataMatrix.getRowCount(); instance++) {
	        double errorAcrossOutputNodes = 0;
	        double[] predictedLabel = labelsOnlyDataMatrix.getRow(instance); // this is the target
	        predictInstanceLabelsFromFeatures(featuresOnlyDataMatrix.getRow(instance), labelsOnlyDataMatrix.getRow(instance));
	        for (int col = 0; col < globalStoredOutputNodeFNetValues.length; col++) {
	            errorAcrossOutputNodes += (globalStoredOutputNodeTargetValues[col] - globalStoredOutputNodeFNetValues[col]);
	        }
	        sumSquaredError += (errorAcrossOutputNodes * errorAcrossOutputNodes);
	    }

	    double MSE = (sumSquaredError / (featuresOnlyDataMatrix.getRowCount() * globalStoredOutputNodeFNetValues.length));

	    return MSE;
	}
}







	
	